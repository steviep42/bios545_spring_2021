#' rootfind5: A package for finding roots
#'
#' This package provides functions:
#' \code{\link{mySqrt}}
#'
#' @details
#' This package implements a single function to find the roots of functions
#' It is under development so there will be other functions available soon that
#' provide other methods.
#'
#' @section rootfind5 functions:
#' mySqrt
#'
#' @docType package
#' @name rootfind5
NULL
