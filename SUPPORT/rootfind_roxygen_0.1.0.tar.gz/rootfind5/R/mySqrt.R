#' Root Finding
#'
#' \code{mySqrt} returns the square root of a number
#'
#' @author Steve Pittard \email{wsp@emory.edu}
#'
#' @usage mySqrt(x)
#'
#' @param x A numeric value or vector
#' @return A computed square root of the argument x
#'   \url{https://en.wikipedia.org/wiki/Root-finding_algorithm}
#'
#'   If x is negative then the complex square root will be returned
#'   \url{https://en.wikipedia.org/wiki/Root-finding_algorithm} for more details.
#'
#' @details
#' This is a function for computing the square root of a number.
#' Compare this to the \code{\link{sqrt}} function.
#'
#' @references Pittard, WS (2018) A New Method for Computing Roots
#' @seealso \code{\link{sqrt}}
#' @examples
#' mySqrt(16)
#' mySqrt(-16)
#' @export
#'
mySqrt <- function(x) {
   if (!is.numeric(x)) {
        stop("The argument needs to be a number")
   }
   if (x < 0) {
        retval <- sqrt(as.complex(x))
   } else {
        retval <- sqrt(x)
}
   return(retval)
}
